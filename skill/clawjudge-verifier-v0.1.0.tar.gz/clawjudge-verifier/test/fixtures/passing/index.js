// A simple function that passes tests
function add(a, b) {
  return a + b;
}

module.exports = { add };
