/**
 * Failing Project - Has syntax errors
 */

// Syntax error: missing closing brace
function brokenFunction() {
  if (true) {
    console.log("This won't compile")
  // Missing closing brace here

// Another syntax error
const x = 
